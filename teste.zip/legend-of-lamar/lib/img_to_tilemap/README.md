# Script que converte um mapa para um tilemap de acordo com a ordem dos tiles no tileset

